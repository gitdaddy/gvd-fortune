#include "basicIo.h"
#include "basicDefs.h"
#include <stdio.h>
#include <string.h>
/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/


FILE *FopenRead(char *fileName)
{
  FILE *aFile;
  aFile = fopen(fileName,"r");
  return(aFile);
};

FILE *FopenWrite(char *fileName)
{
  FILE *aFile;
  if ((fileName != NULL) && (strlen(fileName) > 0))
    aFile = fopen(fileName,"w");
  else
    aFile = stdout;

  return(aFile);
};

void Fheader(FILE *aFile)
{
  fprintf(aFile,"################################################\n");
  fprintf(aFile,"#                                              #\n");
  fprintf(aFile,"#    Data file for random polygon generator    #\n");
  fprintf(aFile,"#                                              #\n");
  fprintf(aFile,"#    written by T. Auer - tom@cosy.sbg.ac.at   #\n");
  fprintf(aFile,"#                                              #\n");
  fprintf(aFile,"#          as part of my master thesis         #\n");
  fprintf(aFile,"#                                              #\n");
  fprintf(aFile,"#          extended by Martin Heimlich         #\n");
  fprintf(aFile,"#           mheimlich@cosy.sbg.ac.at           #\n");
  fprintf(aFile,"#                                              #\n");
  fprintf(aFile,"################################################\n");
};

void FreadLine(FILE *aFile,char *aLine,int lineSize)
{
  do {
    fgets(aLine,lineSize,aFile);
  } while(*aLine == '#');
};

int Fclose(FILE *aFile)
{
  if (aFile != stdout)
    return(fclose(aFile));
  else
    return(TRUE);
};

