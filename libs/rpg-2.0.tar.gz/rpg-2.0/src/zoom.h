#include "basicGeom.h"
#include "pointList.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#ifndef __ZOOM_H_
#define __ZOOM_H_

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/

enum t_ZMactionState {ZM_FIRST,ZM_SECOND,ZM_NONE};

/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/

double ZMxZoomToCoord(double x);

double ZMyZoomToCoord(double y);

double ZMxCoordToZoom(double x);

double ZMyCoordToZoom(double y);

int ZMclipPoint(t_point aPoint);

int ZMclipLine(t_point *point1,t_point *point2);

void ZMoriginalScale();

void ZMzoomIn();

void ZMzoomOut();

void ZMbestFit(t_pointList *pList);

void ZMsetZoom(t_point minPoint,t_point maxPoint);

void ZMsetAction();

void ZMclearAction();

void ZMdoAction(double x,double y);

#endif
