#include "basicPoly.h"
#include "pointArray.h" 
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#ifndef __MGROWINGPOLY_H_
#define __MGROWINGPOLY_H_

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/


/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/

typedef struct {
  int orig;
  int dest;
  int visible;  /* has there been an edge in fronty of this edge? */
} t_McompEdge;


/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
#ifdef DO_STATS
void MRgrowingPoly();

void MGgrowingPoly(unsigned long *tries);
#endif



void MgrowingPoly(t_polygon *aPolygon,t_pointArray *pArray,int nrOfPolys,
		  FILE *outFile);

void MgrowingPolyII(t_polygon *aPolygon,t_pointArray *pArray,int nrOfPolys,
		  FILE *outFile);

#endif
