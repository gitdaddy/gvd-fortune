#include "gtkgui.h"
#include "notYet.h"

/* 13.04.2003 mheimlich: use our own popup */

void notYet()
{
  popup("Warning\n This feature has not been implemented by now.\nIt will be added as soon as possible");
}
