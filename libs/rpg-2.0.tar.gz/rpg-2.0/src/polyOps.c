#include "gtkgui.h"
#include "MCPolygon.h"

#include "polyOps.h"
//#include "formOps.h"
#include "smoothPoly.h"
#include "MbouncePoly.h"
#include "MxmonoPoly.h"
#include "MstarPoly.h"
#include "MgrowingPoly.h"
#include "M2optPoly.h"
#include "M2optPolyII.h"
#include "MspPoly.h"
#include "MrejectPoly.h"
#include "MsearchPoly.h"
#include "MtriangPoly.h"
#include "basicPoly.h"
#include "pointArray.h"
#include "ipeWrite.h"
#include "stateLine.h"
#include "zoom.h"
#include "basicIo.h"
#include "analysis.h"
#include "analysisII.h"
#include "withX.h"
/* #include "linkDiam.h" */
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/


static t_polygon aPolygon;
static t_pointArray pArray;

/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
void YOinit()
{
  BPinit(&aPolygon,0);
  PAinitEmptyArray(&pArray);
}


void YOfree()
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
}


void YOclearPoly()
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  BPinit(&aPolygon,0);
  PAinitEmptyArray(&pArray);

  /**/
  MCclear();
}

void YOipeWrite(FILE *ipeFile)
{
  IWwritePoly(ipeFile,&aPolygon,&pArray);
}

void YOsmoothPoly(t_pointList *pList)
{
  smoothPoly(pList,&pArray,&aPolygon);

  MFredrawFree();
}


void YObouncePoly(int nrOfMoves,t_pointList *pList)
{

  BPfree(&aPolygon);
  PAfreeArray(&pArray);

  PAlistInitArray(&pArray,pList);

  MbouncePoly(pList,&aPolygon,&pArray,nrOfMoves);

  MFredrawFree();
}

void YOxmonoPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MxmonoPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOstarPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MstarPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOnewStarPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MnewStarPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOfastStarPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MfastStarPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOgrowingPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MgrowingPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOgrowingPolyII(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MgrowingPolyII(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YO2optPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  M2optPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YO2optPolyII(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  M2optPolyII(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YO2optPolyIII(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  M2optPolyIII(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOspPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MspPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOrejectPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MrejectPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOsearchPoly(t_pointList *pList)
{
  BPfree(&aPolygon);
  PAfreeArray(&pArray);
  
  PAlistInitArray(&pArray,pList);

  MsearchPoly(&aPolygon,&pArray,1,NULL);

  MFredrawFree();
}

void YOtriangPoly(int nrOfVertices,t_pointList *pList)
{
  char msg[255];

  BPfree(&aPolygon);
  PAfreeArray(&pArray);

  PAlistInitArray(&pArray,pList);

  MtriangPoly(pList,&aPolygon,&pArray,nrOfVertices,1,NULL);

  if (PAnrOfPoints(&pArray) != nrOfVertices)
    {
			/* 13.04.2003 mheimlich: use our own popup */
      sprintf(msg,"Polygon contains only %i instead\n of %i vertices (as specified).",PAnrOfPoints(&pArray), nrOfVertices);

      if (isWithX())
				popup(msg);
      else
	fprintf(stderr,"%s",msg);
    }
  
  MFredrawFree();
}

void YOdrawPoly()
{
  int count;
  t_point point1,point2;
  
  MFinitFPoly(BPsizeOf(&aPolygon));

  for(count=1;count<= BPsizeOf(&aPolygon);count++)
  {
    point1 = PAgetPoint(&pArray,BPgetPIndex(&aPolygon,count));
    MFaddToFPoly(ZMxCoordToZoom(point1.x),ZMyCoordToZoom(point1.y),count);
  }
  MFdrawFPoly();

  /* 13.4.2003 mheimlich: Outline is already drawn with MFdrawFPoly() */
	/*
  for(count=0;count< BPsizeOf(&aPolygon);count++)
  {
    point1 = PAgetPoint(&pArray,BPgetPIndex(&aPolygon,
                                           (count%BPsizeOf(&aPolygon))+1));
    point2 = PAgetPoint(&pArray,BPgetPIndex(&aPolygon,
                                           ((count+1)%BPsizeOf(&aPolygon))+1));

    if (ZMclipLine(&point1,&point2))
	MFdrawLine(ZMxCoordToZoom(point1.x),ZMyCoordToZoom(point1.y),
		   ZMxCoordToZoom(point2.x),ZMyCoordToZoom(point2.y));

  }*/
}

void YOloadPoly(char *fileName,t_pointList *pList)
{
  if (fileName != NULL)
  {
    BPfree(&aPolygon);
    PAfreeArray(&pArray);
    PLfreeList(pList);
    PLinitList(pList);

    PAinitArray(&pArray,0);

    if (!BPreadFile(&aPolygon,&pArray,fileName))
    {
      SLsetState(ST_FLE_N_FND);
    }
    else
    {
      PAsortArray(&pArray);
      PAcreateList(&pArray,pList);
    }

    MFredrawFree();
  }
}

void YOwritePoly(char *fileName)
{
  if (fileName != NULL)
  {
    if (!BPwriteFile(&aPolygon,&pArray,fileName))
      SLsetState(ST_FLE_N_FND);

    MFredrawFree();
  }
}

void YOwriteVoronoi(char *fileName)
{
  int count;
  t_point min,max,curPoint;
  FILE *vFile;

  if (BPsizeOf(&aPolygon) > 0)
    {
      if ((vFile = FopenWrite(fileName)) != NULL)
	{
	  /* get bounding box */
	  PAgetMinMax(&pArray,&min,&max);

	  /* begin the file */
	  fprintf(vFile,"%f %f %f %f\n",min.x,min.y,max.x,
		  max.y);
	  fprintf(vFile,"1\n");
	  fprintf(vFile,"%u\n",BPsizeOf(&aPolygon));
	  fprintf(vFile,"1\n");

	  /* write all the points */
	  for(count=1;count <= BPsizeOf(&aPolygon);count++)
	    {
	      curPoint =  PAgetPoint(&pArray,BPgetPIndex(&aPolygon,count));
	      fprintf(vFile,"0\n");
	      fprintf(vFile,"%20.15f %20.15f 0.0 0.0\n",curPoint.x,curPoint.y);
	    }

	  /* close the line */
	  Fclose(vFile);
	}
    }
}


void YOwriteMartin(char *fileName)
{
  int count;
  t_point min,max,curPoint;
  FILE *vFile;

  if (BPsizeOf(&aPolygon) > 0)
    {
      if ((vFile = FopenWrite(fileName)) != NULL)
	{
	  fprintf(vFile,"%u\n",BPsizeOf(&aPolygon));
      
	  /* write all the points */
	  for(count=1;count <= BPsizeOf(&aPolygon);count++)
	    {
	      curPoint =  PAgetPoint(&pArray,BPgetPIndex(&aPolygon,count));
	      fprintf(vFile,"%20.15f %20.15f\n",curPoint.x,curPoint.y);
	    }
	  
	  /* close the line */
	  Fclose(vFile);
	}
    }
}
  
void YOlengthDist(char *fileName,int nrOfClasses)
{
  lengthDist(&pArray,&aPolygon,nrOfClasses,fileName);
}

void YOslopeDist(char *fileName,int nrOfClasses)
{
  slopeDist(&pArray,&aPolygon,nrOfClasses,fileName);
}

void YOangleDist(char *fileName,int nrOfClasses)
{
  angleDist(&pArray,&aPolygon,nrOfClasses,fileName);
}

void YOsinuosity(char *fileName)
{
  sinuosity(&pArray,&aPolygon,fileName);
}

/*
void YOlinkDiam(char *fileName)
{
  linkDiam(&pArray,&aPolygon,fileName);
}
*/

void YOsinuosityII()
{
  sinuosityII(&pArray,&aPolygon);
}


void YOanalysisII()
{
  lengthDistII(&pArray,&aPolygon);
  slopeDistII(&pArray,&aPolygon);
  angleDistII(&pArray,&aPolygon);
  sinuosityII(&pArray,&aPolygon);
  /* linkDiamII(&pArray,&aPolygon); */
}

/* 5.6.2003 mheimlich: */
void YOgetPoly(t_polygon **polygon, t_pointArray **points)
{
  *polygon = &aPolygon;
  *points = &pArray;
  /*
  PAinitArray(points, PAnrOfPoints(&pArray));
  PAcopyArray(&pArray, points);

  BPinit(polygon,  BPsizeOf(&aPolygon));
  BPcopyPoly(&aPolygon, polygon);
  */
}
