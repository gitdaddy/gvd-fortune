/***************************************************************************
 *   Copyright (C) 2003 by Martin Heimlich                                 *
 *   mheimlich@cosy.sbg.ac.at                                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************/

#include "basicPoly.h"

#ifndef __MCPOLYGON_H_
#define __MCPOLYGON_H_

/* Multiply connected Polygons */
void MCPolygon2(t_polygon *aPolygon, t_pointArray *pArray, int hcount);
void MCsmoothPoly(t_pointList *aList, t_pointArray *pArray);
void MCreset();
void MCclear();
int MCsavePoly(char* filename, t_pointArray *pArray);
void MCwriteVoronoi(char *fileName, t_pointArray *pArray);
void MCipeWrite(FILE *ipeFile, t_pointArray *pArray);
t_polygon* MCgetNextPolygon();

#endif

