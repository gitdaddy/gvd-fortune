/* This is the main program                                       */
/* If possible, the functonality is located in routines that are  */
/* called from main(), otherwise it is done here                  */
/*                                                                */
/* tom 20/11/95                                                   */

/* 12.4.2003 mheimlich: changed to use the new GTK gui            */

//#include "formOps.h"
#include "pointOps.h"
#include "polyOps.h"
#include "eralloc.h"
#include "basicInits.h"
#include "argEval.h"
#include "withX.h"
#include "calcPoly.h"
#include "outWrite.h"
#include "analysisII.h"

#include "gtkgui.h"
/* #include "linkDiam.h" */

int main(int argc,char *argv[])
{
  int format,nrOfPoints,nrOfPolys,seed,smooth;
  int analysis,sinuosity,lenRes,angleRes,slopeRes,count,cluster;
  int auxParam;
  t_pointArray pArray;
  enum t_calcType algo;
  char inFile[255],outFile[255],lenFile[255],angleFile[255],slopeFile[255],
  sinuFile[255],linkFile[255],outFName[255];

  /* do all the necessary initialisations */
  /* basic initializations */
  BIinit();
  erinit();
  /*if (isWithX())
    MFinit(argc,argv);*/

  /* evaluate the command line arguments */
  if (AEeval(argc,argv,&nrOfPoints,&nrOfPolys,&format,&seed,&smooth,&algo,
             inFile,outFName,&analysis,&sinuosity,&angleRes,&lenRes,&slopeRes,
             &auxParam,&cluster))
  {
    /* init the structure for the points */
    /* NOTE: this must be done before calling initForms()! */
    POinit();
    YOinit();

    /* if an input file was specified, load it! */
    if (strlen(inFile) > 0)
      POloadPoints(inFile);

    /* set the set for the random number generator */
    if (seed >= 0)
      srand48(seed);

    /* generate the specified number of random points */
    if (cluster > 0)
      POgenerateClusterPoints(nrOfPoints);
    else if (nrOfPoints > 0)
      POgenerateRandomPoints(nrOfPoints);
    else if (nrOfPoints < 0)
    {
      nrOfPoints = -nrOfPoints;
      POgenerateRandomCirclePoints(nrOfPoints);
    }

    /* initialize the analysis process */
    if (analysis)
    {
      resetAnalysisII(lenRes,slopeRes,angleRes,nrOfPoints,nrOfPolys);
      /* resetLink(nrOfPoints,nrOfPolys); */
    }
    else if (sinuosity)
    {
      resetSinuosityII(nrOfPoints,nrOfPolys);
    }

    PAlistInitArray(&pArray,POgetPointList());
    /* if a method for calculation was specified, calculate
    the polygon */
    for (count=1;count<=nrOfPolys;count++)
    {
      /* restore the initial point set */
      PAcreateList(&pArray,POgetPointList());

      CPsetState(algo,auxParam);
      CPdoCalc();

      /* smooth the polygon if wanted */
      while (smooth > 0)
      {
        CPsetState(CP_SMOOTH,RPG_UNDEFINED);
        CPdoCalc();
        smooth--;
      };

      if ((!analysis) && (!sinuosity))
      {
        if (strlen(outFName) > 0)
          sprintf(outFile,"%s-%03i",outFName,count);
        else
          outFile[0] = 0;

        /* write to an output file */
        OWwrite(outFile,format);
      }
      else if (analysis)
        YOanalysisII();
      else if (sinuosity)
        YOsinuosityII();
    }

    PAfreeArray(&pArray);

    if (analysis)
    {
      if ((strlen(outFile) == 0) || (strcasecmp(outFile,"none") == 0))
        strcpy(outFile,"analysis");

      strcpy(lenFile,outFile);
      strcpy(angleFile,outFile);
      strcpy(slopeFile,outFile);
      strcpy(sinuFile,outFile);
      strcpy(linkFile,outFile);
      strcat(angleFile,".ang");
      strcat(slopeFile,".slp");
      strcat(lenFile,".len");
      strcat(sinuFile,".sin");
      strcat(linkFile,".lnk");

      writeAnalysis(lenFile,slopeFile,angleFile,sinuFile);
      /* writeLink(linkFile); */
    }
    else if (sinuosity)
    {
      if ((strlen(outFile) == 0) || (strcasecmp(outFile,"none") == 0))
        strcpy(outFile,"analysis");

      strcpy(sinuFile,outFile);
      strcat(sinuFile,".sin");

      writeSinuosityII(sinuFile);
    }

    if(isWithX())
		launchGUI(argc, argv);
  }
  erend();

  return(0);
};
