#include "basicDefs.h"
#ifndef NOX11_VERSION
#include "withX.h"
#include "calcPoly.h"
#include "stateLine.h"
#include "zoom.h"
#endif
#include <stdlib.h>
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/


/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/

void BIinit()
{
  srand48(SEED);

#ifndef NOX11_VERSION
  withX();

  /* init the polygonal state */
  CPsetState(CP_IDLE,RPG_UNDEFINED);

  /* init the state line */
  SLsetState(ST_OK);
  
  /* init zoom operations */
  ZMoriginalScale();
  ZMclearAction();
#endif
};

