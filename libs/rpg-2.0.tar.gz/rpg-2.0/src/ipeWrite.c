#include "ipeWrite.h"
#include "basicIo.h"
#include "basicDefs.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
FILE *IWopenFile(char *fileName)
{
  FILE *ipeFile;

  if ((ipeFile = FopenWrite(fileName)) != NULL)
      {
      fprintf(ipeFile,"%%!PS-Adobe-2.0 EPSF-1.2\n");
      fprintf(ipeFile,"%%%%Creator: Ipe 5.0\n\n");
      fprintf(ipeFile,"%% Group\n\n");
    };
  
  return(ipeFile);
};

void IWwriteCoord(FILE *ipeFile,t_point aPoint)
{
  double scale;
  double x,y;

  scale = MIN((X_MAX-X_MIN),(Y_MAX-Y_MIN));

  x = IPE_MIN + (aPoint.x - X_MIN)*(IPE_MAX-IPE_MIN)/scale;
  y = IPE_MIN + (aPoint.y - Y_MIN)*(IPE_MAX-IPE_MIN)/scale;

  fprintf(ipeFile,"%f %f",x,y);
};

void IWwriteFrame(FILE *ipeFile)
{
  t_point auxPoint;

  fprintf(ipeFile,"%% Line\n");
  fprintf(ipeFile,"%% ss 0\n");
  fprintf(ipeFile,"0.4 [] ss\n");
  fprintf(ipeFile,"np %% # 4\n");
  auxPoint.x = X_MIN;
  auxPoint.y = Y_MIN;
  IWwriteCoord(ipeFile,auxPoint);
  fprintf(ipeFile," mt\n");
  auxPoint.y = Y_MAX;
  IWwriteCoord(ipeFile,auxPoint);
  fprintf(ipeFile," lt\n");
  auxPoint.x = X_MAX;
  IWwriteCoord(ipeFile,auxPoint);
  fprintf(ipeFile," lt\n");
  auxPoint.y = Y_MIN;
  IWwriteCoord(ipeFile,auxPoint);
  fprintf(ipeFile," lt\n");

  fprintf(ipeFile,"cl %% cl\n");
  fprintf(ipeFile,"%% sk\n");
  fprintf(ipeFile,"0 sg sk\n");
  fprintf(ipeFile,"%% End\n\n");
};

void IWwritePoint(FILE *ipeFile,t_point aPoint)
{
  fprintf(ipeFile,"%% Mark\n");
  fprintf(ipeFile,"%% sk\n");
  fprintf(ipeFile,"0 sg\n");
  fprintf(ipeFile,"%% ty 2\n");
  fprintf(ipeFile,"%% sz\n");
  fprintf(ipeFile,"2\n");
  fprintf(ipeFile,"%% xy\n");
  IWwriteCoord(ipeFile,aPoint);
  fprintf(ipeFile," m2\n");
  fprintf(ipeFile,"%% End\n\n");
};

void IWwritePoints(FILE *ipeFile,t_pointArray *pArray)
{
  int count;

  for(count=1;count <= PAnrOfPoints(pArray);count++)
    {
      IWwritePoint(ipeFile,PAgetPoint(pArray,count));
    }
};

void IWwritePoly(FILE *ipeFile,t_polygon *aPoly,t_pointArray *pArray)
{
  int first;
  int count;
  
  first = TRUE;

  if (BPsizeOf(aPoly) > 0)
    {
      first = TRUE;
      
      /* begin the line */
      fprintf(ipeFile,"%% Line\n");
      fprintf(ipeFile,"%% ss 0\n");
      fprintf(ipeFile,"0.4 [] ss\n");
      fprintf(ipeFile,"np %% # %u\n",BPsizeOf(aPoly));
      
      /* write all the points */
      for(count=1;count <= BPsizeOf(aPoly);count++)
	{
	  IWwriteCoord(ipeFile,PAgetPoint(pArray,BPgetPIndex(aPoly,count)));
	  if (first)
	    {
	      fprintf(ipeFile," mt\n");
	      first = FALSE;
	    }
	  else
	    fprintf(ipeFile," lt\n");
	};
	
	/* close the line */
	fprintf(ipeFile,"cl %% cl\n");
	fprintf(ipeFile,"%% sk\n");
	fprintf(ipeFile,"0 sg sk\n");
	fprintf(ipeFile,"%% End\n");  
    };
};

void IWcloseFile(FILE *ipeFile)
{
  fprintf(ipeFile,"%% End\n\n");
  fprintf(ipeFile,"end %%%% of Ipe figure\n");
  
  Fclose(ipeFile);
};




