#include "pointArray.h"
#include "basicPoly.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#ifndef __MSTARPOLY_H_
#define __MSTARPOLY_H_

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
#ifdef DO_STATS
void MRfastStarPoly();

void MGfastStarPoly(unsigned long *tries);
#endif


void MstarPoly(t_polygon *aPolygon,t_pointArray *pArray,int nrOfPolys,
	       FILE *outFile);

void MfastStarPoly(t_polygon *aPolygon,t_pointArray *pArray,int nrOfPolys,
		   FILE *outFile);

void MnewStarPoly(t_polygon *aPolygon,t_pointArray *pArray,int nrOfPolys,
		  FILE *outFile);

#endif
