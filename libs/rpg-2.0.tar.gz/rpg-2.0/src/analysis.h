#include "pointArray.h"
#include "basicPoly.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#ifndef __ANALYSIS_H_
#define __ANALYSIS_H_

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
void angleDist(t_pointArray *pArray,t_polygon *aPolygon,int nrOfClasses,
	   char *fName);

void lengthDist(t_pointArray *pArray,t_polygon *aPolygon,int nrOfClasses,
	   char *fName);

void slopeDist(t_pointArray *pArray,t_polygon *aPolygon,int nrOfClasses,
	   char *fName);

void sinuosity(t_pointArray *pArray,t_polygon *aPolygon,char *fName);

#endif
