#include "calcPoly.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#ifndef __ARGEVAL_H_
#define __ARGEVAL_H_

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/

/* output formats */
#define STANDARD     1
#define IPE          2
#define VORONOI      3
#define POLY         4
/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/


/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/

int AEeval(int argc,char *argv[],int *nrOfPoints,int *nrOfPolys,
	   int *format,int *seed,int *smooth,enum t_calcType *algo,
	   char *inFile,char *outFile,int *analysis,int *sinuosity,
	   int *angRes,int *lenRes,int *slopeRes,int *auxParam,int *cluster);


#endif








