
/***************************************************************************
 *   Copyright (C) 2003 by Martin Heimlich                                 *
 *   mheimlich@cosy.sbg.ac.at                                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#include "gtkgui.h"

//rpg includes
#include "user.h"
#include "pointOps.h"
#include "polyOps.h"
#include "basicDefs.h"
#include "notYet.h"
#include "stateLine.h"
#include "ipeWrite.h"
#include "zoom.h"
#include "calcPoly.h"
#include "eralloc.h"
#include "basicPoly.h"
#include "withX.h"

#include <time.h>
#include "MCPolygon.h"
#include "elapsed.h"

/* global gui variables */
static GtkWidget *mainWnd = NULL;
static GtkWidget *textOutput = NULL;
static GtkWidget *drawArea = NULL;
static GdkPixmap *pixmap = NULL;
static GtkItemFactory *itemFactory = NULL;
static GtkCheckMenuItem *polyFillToggle= NULL;
static GtkCheckMenuItem *pointMarkersToggle= NULL;
static GtkCheckMenuItem *addPointsToggle= NULL;
static GtkCheckMenuItem *delPointsToggle= NULL;
static GtkCheckMenuItem *writeFileToggle= NULL;
static GtkCheckMenuItem *solarisToggle= NULL;

GdkGC *gcOutline, *gcFill, *gcPoint, *gcHoles;

static int rightMouseButton = FALSE;
static int oldX, oldY;

/* formOps variables */
static GdkPoint *MFxpArray;
static int MFxpSize;
static int MFfillPoly, MFmarkPoints;

static t_polygon *aPolygon;
static t_pointArray *pArray;
static int MCP = FALSE;

/*************************************************************************
formOps wrapper functions
*************************************************************************/

void MFredrawFree()
{
    if (isWithX())
		redrawAll();
};

void MFinitFPoly(int size)
{
	if (isWithX()){
		MFxpSize = size;
  		if (MFxpSize > 0)
    		MFxpArray = (GdkPoint *)ercalloc(MFxpSize,sizeof(GdkPoint));
	};
};

void MFaddToFPoly(double x,double y,int index)
{
	if (isWithX())
	{	if((index > 0) && (index <= MFxpSize))
  		{
    		(MFxpArray+(index-1))->x = (gint16)((x * ((double) getDrawAreaWidth())) + 0.5);
    		(MFxpArray+(index-1))->y = (gint16)(((1.0 - y) * ((double) getDrawAreaHeight())) + 0.5);
  		};
	};
};

void MFdrawPoint(double x,double y)
{
  if (isWithX()){
	  gint16 xcord, ycord;
	  int smaller = 0;

	  if(MFmarkPoints)
  	{
   		 xcord = (gint16)((x * ((double) getDrawAreaWidth())) + 0.5);
    	ycord = (gint16)(((1.0 - y) * ((double) getDrawAreaHeight())) + 0.5);
    	gdk_draw_line(pixmap, gcPoint, xcord - RADIUS, ycord, xcord + RADIUS, ycord);
    	gdk_draw_line(pixmap, gcPoint, xcord, ycord - RADIUS, xcord, ycord + RADIUS);
  	}
  }
};

void MFdrawFPoly()
{
  if (isWithX()){
	  int i;
	  if (MFxpSize > 0)
  		{
   	 		if(MFfillPoly && !(solarisToggle->active && MFxpSize > 65535))
      		gdk_draw_polygon(pixmap, gcFill, TRUE, MFxpArray, MFxpSize);

		    for(i=0;i<MFxpSize-1;i++)
     		 gdk_draw_line(pixmap, gcOutline, MFxpArray[i].x, MFxpArray[i].y, MFxpArray[i+1].x, MFxpArray[i+1].y);

		    gdk_draw_line(pixmap, gcOutline, MFxpArray[0].x, MFxpArray[0].y, MFxpArray[MFxpSize-1].x, MFxpArray[MFxpSize-1].y);

		    erfree(MFxpArray);
  		};
	};
};

/*************************************************************************
Callback functions
*************************************************************************/

/** A callback dummy
 *  A callback dummy used for not implemented functions
 */
void cbNotImp(GtkWidget *widget, gpointer data)
{
  out("function not implemented yet\n");
}

/** File menu callback */
void cbFile(GtkWidget *widget, guint action, gpointer data)
{
  char* tmp = NULL;
  char buffer[255];
  int ival;
  float fval;

  switch(action)
  {
  case 1:
    srand48(SEED);
    out("Generator reset\n");
    break;

  case 2:
    sprintf(buffer, "%d", SEED);
    tmp = popupInput("Please enter a seed value", buffer);
    if(tmp != NULL)
    {
      ival = atoi(tmp);
      srand48(ival);
      sprintf(buffer, "Seed set to %d\n", ival);
      out(buffer);
    }
    break;

  case 3:
    sprintf(buffer, "%16.15f", getDelta());
    tmp = popupInput("Please enter a delta value", buffer);
    if(tmp != NULL)
    {
      fval = atof(tmp);
      setDelta(fval);
      sprintf(buffer, "Delta set to %s\n", tmp);
      out(buffer);
    }
    break;
  }
}

/** WriteFile menu callback */
void cbWriteFile(GtkWidget *widget, guint action, gpointer data)
{
  char* fname = NULL;
  FILE *ipeFile;

  if((fname = getFilename()) != NULL)
  {
    switch(action)
    {
    case 1:
      out("Writing Ipe file...");
      ipeFile = IWopenFile(fname);
      IWwriteFrame(ipeFile);
      POipeWrite(ipeFile);
      if(MCP)
        MCipeWrite(ipeFile, pArray);
      else
        YOipeWrite(ipeFile);
      IWcloseFile(ipeFile);
      break;

    case 2:
      out("Writing Voronoi file...");
      if(MCP)
        MCwriteVoronoi(fname, pArray);
      else
        YOwriteVoronoi(fname);

      break;

    case 3:
      out("Writing Poly file...");
      YOwriteMartin(fname);
      break;
    }
    out("done!\n");
  }
}

/** Load/save points menu callback */
void cbLSPoint(GtkWidget *widget, guint action, gpointer data)
{
  char* fname = NULL;
  if((fname = getFilename()) != NULL)
  {
    switch(action)
    {
    case 1:
      out("Loading points from file...");
      POloadPoints(fname);
      break;

    case 2:
      out("Saving points to file...");
      POwritePoints(fname);
      break;
    }
    out("done!\n");
  }
}

/** Generate points menu callback */
void cbGenPoint(GtkWidget *widget, guint action, gpointer data)
{
  char* tmp = NULL;
  int pcount;
  char buffer[255];

  tmp = popupInput("Please enter a the number of points", "3");
  if(tmp != NULL)
  {
    MFmarkPoints = TRUE;
    pointMarkersToggle->active = TRUE;
    ZMoriginalScale();
    pcount = atoi(tmp);
    sprintf(buffer, "Generating %d ", pcount);

    switch(action)
    {
      /*generate random points */
    case 1:
      out(buffer);
      out("random points (square)...");
      CPsetState(CP_POINTS, pcount);
      break;

    case 2:
      out(buffer);
      out("random points (circle)...");
      CPsetState(CP_CIRCLEPOINTS, pcount);
      break;

    case 3:
      out(buffer);
      out("random points (clustered)...");
      CPsetState(CP_CLUSTERPOINTS, pcount);
      break;
    }

    CPdoCalc();
    out("done!\n");
  }
}

/** Add/remove points */
void cbARPoints(GtkWidget *widget, guint action, gpointer data)
{
  switch(action)
  {
  case 1:
    if(addPointsToggle->active)
    {
      delPointsToggle->active = FALSE;
      MFmarkPoints = TRUE;
      POsetActionAdd();
    }
    else
      POclearAction();
    break;

  case 2:
    if(delPointsToggle->active)
    {
      addPointsToggle->active = FALSE;
      MFmarkPoints = TRUE;
      POsetActionDelete();
    }
    else
      POclearAction();
    break;
  }
}

/** Clear points */
void cbClearPoints(GtkWidget *widget, guint action, gpointer data)
{
  MFmarkPoints = TRUE;
  ZMoriginalScale();
  POclearPoints();
  out("Points cleared\n");
}

/** Load/save polygon menu callback */
void cbLSPoly(GtkWidget *widget, guint action, gpointer data)
{
  char* fname = NULL;
  t_pointList *pointList;

  if((fname = getFilename()) != NULL)
  {
    switch(action)
    {
    case 1:
      out("Loading polygon from file...");
      ZMoriginalScale();
      pointList = POgetPointList();
      YOloadPoly(fname, pointList);
      break;

    case 2:
      out("Saving polygon to file...");
      if(MCP)
        MCsavePoly(fname, pArray);
      else
      	YOwritePoly(fname);
      break;
    }
    out("done!\n");
  }
}

/** Calculate polygon menu callback */
void cbCalcPoly(GtkWidget *widget, guint action, gpointer data)
{
  char* tmp = NULL;
  char buffer[100];
  int scount, i;
  double cputime;
  t_pointList *pointList;
  t_pointArray tmpPA;
  t_point tmpPoint;

  ZMoriginalScale();

  if(action > 2 && action < 13 && MCP)
  {
    out("Sorting pointlist...");
    pointList = POgetPointList();
    PAinitArray(&tmpPA, PLcountPoints(pointList));

    i = 0;
    PLresetList(pointList);
    while(PLgetCurrentPoint(pointList, &tmpPoint))
    {
        PAsetPoint(&tmpPA, ++i, tmpPoint);
    }

    PLcleanList(pointList);
    PAsortArray(&tmpPA);
    PAcreateList(&tmpPA, pointList);
    PAfreeArray(&tmpPA);
    out("done!\n");
  }

  elapsed();

  switch(action)
  {
  case 1:
    out("Smoothing polygon...");
    if(MCP)
    {
        pointList = POgetPointList();
        MCsmoothPoly(pointList, pArray);
        //YOdrawPoly();
        //popup("Smoothing original polygon only!");
    }
    else
    {
        //MCP = FALSE;
        CPsetState(CP_SMOOTH,RPG_UNDEFINED);
    }
    break;

  case 2:
    tmp = popupInput("Please enter a the number of steps", "1");
    if(tmp != NULL)
    {
      scount = atoi(tmp);
      out("Computing Bouncing Vertices...");
      MCP = FALSE;
      CPsetState(CP_BOUNCE, scount);
    }
    break;

  case 3:
    out("Computing x-monotone polygon...");
    MCP = FALSE;
    CPsetState(CP_XMONO,RPG_UNDEFINED);
    break;

  case 4:
    out("Computing star-shaped polygon...");
    MCP = FALSE;
    CPsetState(CP_ARRANGE_STAR,RPG_UNDEFINED);
    break;

  case 5:
    out("Computing star universe polygon...");
    MCP = FALSE;
    CPsetState(CP_STAR,RPG_UNDEFINED);
    break;

  case 6:
    out("Computing fast star-shaped polygon...");
    MCP = FALSE;
    CPsetState(CP_FAST_STAR,RPG_UNDEFINED);
    break;

  case 7:
    out("Computing Steady Growth...");
    MCP = FALSE;
    CPsetState(CP_GROWING_II,RPG_UNDEFINED);
    break;

  case 8:
    out("Computing 2-opt Moves...");
    MCP = FALSE;
    CPsetState(CP_2OPT_II,RPG_UNDEFINED);
    break;

  case 9:
    out("Computing Space Partitioning...");
    MCP = FALSE;
    CPsetState(CP_SPACE_PART,RPG_UNDEFINED);
    break;

  case 10:
    out("Computing Permute & Reject...");
    MCP = FALSE;
    CPsetState(CP_REJECT,RPG_UNDEFINED);
    break;

  case 11:
    out("Computing Incremental Construction...");
    MCP = FALSE;
    CPsetState(CP_SEARCH,RPG_UNDEFINED);
    break;

  case 12:
    tmp = popupInput("Please enter a the number of vertices", "1");
    if(tmp != NULL)
    {
      elapsed();
      scount = atoi(tmp);
      out("Computing Triangle Select...");
      MCP = FALSE;
      CPsetState(CP_TRIANGLE, scount);
    }
    break;

  case 13:
    tmp = popupInput("Please enter the number of holes", "1");
    if(tmp != NULL)
    {
      elapsed();
      scount = atoi(tmp);
      out("Computing multiply connected polygon...");
      MCP = TRUE;
      MCclear();
      YOgetPoly(&aPolygon, &pArray);
      if(BPsizeOf(aPolygon))
      {
        MCPolygon2(aPolygon, pArray, scount);
        redrawAll();
      }
      else
        popup("\n  Please create a \"normal\" polygon first  \n");
    }
    break;
  }


  CPdoCalc();

  sprintf(buffer, "done! (%.3f ms)\n", elapsed());

  out(buffer);
}

/** Analysis menu callback */
void cbAnalysis(GtkWidget *widget, guint action, gpointer data)
{
  char* tmp = NULL;
  char* fname = NULL;

  tmp = popupInput("Please enter a the number of classes", "10");
  if(tmp != NULL)
  {
    if(!aGetFile() || (fname = getFilename()) != NULL)
    {
      switch(action)
      {
      case 1:
        out("Calculating angle distribution...\n");
        YOangleDist(fname, atoi(tmp));
        break;

      case 2:
        out("Calculating slope distribution...\n");
        YOslopeDist(fname, atoi(tmp));
        break;

      case 3:
        out("Calculating length distribution...\n");
        YOlengthDist(fname, atoi(tmp));
        break;
      }
      out("done!\n");
    }
  }
}

/** Sinuosity callback */
void cbASino(GtkWidget *widget, gpointer data)
{
  char* fname = NULL;
  if(!aGetFile() || (fname = getFilename()) != NULL)
  {
    out("Calculating sinuosity...\n");
    YOsinuosity(fname);
    out("done!\n");
  }
}

/** toggle write file callback */
void cbAFile(GtkWidget *widget, gpointer data)
{
  aToggleFile();
}

/** View menu callback */
void cbView(GtkWidget *widget, guint action, gpointer data)
{
  t_pointList *pointList;

  switch(action)
  {
  case 1:
    out("Zooming to original size\n");
    ZMoriginalScale();
    break;

  case 2:
    out("Zooming to best fit\n");
    pointList = POgetPointList();
    ZMbestFit(pointList);
    break;

  case 3:
    out("Zooming in\n");
    ZMzoomIn();
    break;

  case 4:
    out("Zooming out\n");
    ZMzoomOut();
    break;

  case 5:
    addPointsToggle->active = FALSE;
    delPointsToggle->active = FALSE;
    POclearAction();
    ZMsetAction();
    out("Click on the upper left and lower right corner of the region you wish to zoom in\n");
    break;

  case 6:
    MFfillPoly = !MFfillPoly;
    MFredrawFree();
    out("Polygon Fill toggled\n");
    break;

  case 7:
    MFmarkPoints = !MFmarkPoints;
    MFredrawFree();
    out("Point Markers toggled\n");
    break;

  case 8:
    MFredrawFree();
    if(solarisToggle->active)
      out("Solaris X Server Workaround enabled\n");
    else
    	out("Solaris X Server Workaround disabled\n");
    break;
  }
  redrawAll();
}

/** Show about box */
void cbAbout(GtkWidget *widget, gpointer data)
{
  popup("\n         Programmed by:         \n\nThomas Auer\nMichael Gschwandtner\nMartin Heimlich\nMartin Held\n\n\n Please send comments and bug reports to Martin Held \nat <held@cosy.sbg.ac.at>");
}

gint cbDeleteEvent(GtkWidget *widget, GdkEvent *event, gpointer data)
{
  guip("delete event from window manager");
  return FALSE;
}

void cbDestroy(GtkWidget *widget, gpointer data)
{
  guip("received destroy signal, quitting...");
  gtk_main_quit();
}

/*
void cbHandleCommand(GtkWidget *widget, GdkEventKey *event, gpointer data)
{
  if(event->keyval == 65293)// || event->keyval == 65421)
  {
    out(gtk_entry_get_text(GTK_ENTRY(widget)));
    out(": Sorry, command handling is not implemented yet\n");
    gtk_entry_set_text(GTK_ENTRY(widget), "");
  }
}
*/

gint cbAreaClick(GtkWidget *widget, GdkEventButton *event)
{
  double x,y;
  x = ((double) (event->x - 1))/((double) getDrawAreaWidth());
  y = 1.0 - ((double) (event->y - 1))/((double) getDrawAreaHeight());

  switch(event->button)
  {
  case 1:
    POdoAction(x,y,((double)EPSILON)/((double) getDrawAreaWidth()));
    break;

  case 3:
    rightMouseButton = TRUE;
    oldX = event->x;
    oldY = event->y;
    break;
  }

  ZMdoAction(x,y);
  return FALSE;
}

gint cbAreaRelease(GtkWidget *widget, GdkEventButton *event)
{
  if(event->button == 3)
    rightMouseButton = FALSE;

  return FALSE;
}

gint cbAreaLeave(GtkWidget *widget, GdkEvent *event)
{
  rightMouseButton = FALSE;

  return FALSE;
}

void movePolygon(int u, int v)
{
  double x,y;
  x = ((double) (-u))/((double) getDrawAreaWidth());
  y = 1.0 - ((double) (-v))/((double) getDrawAreaHeight());

  ZMclearAction();
  ZMsetAction();
  ZMdoAction(x,y);
  ZMdoAction(x + 1, y - 1);
}

gint cbAreaMove(GtkWidget *widget, GdkEventMotion *event)
{
  if(rightMouseButton)
  {
    movePolygon(event->x - oldX, event->y - oldY);
    oldX = event->x;
    oldY = event->y;
  }
  return FALSE;
}

gint cbAreaResize(GtkWidget *widget, GdkEventConfigure *event)
{
  if (pixmap)
    gdk_pixmap_unref(pixmap);

  pixmap = gdk_pixmap_new(widget->window,
                          widget->allocation.width,
                          widget->allocation.height,
                          -1);
  MFredrawFree();

  return TRUE;
}

gint cbAreaRedraw(GtkWidget *widget, GdkEventExpose *event)
{
  redraw();
  return FALSE;
}

/*************************************************************************
Service section
*************************************************************************/

/** Prints messages to stdout */
void guip(char *msg)
{
  g_print("GUI :: %s\n", msg);
}

/** prints messages in the output area */
void out(char *msg)
{
  gtk_text_insert(GTK_TEXT(textOutput), NULL, NULL, NULL, msg, strlen(msg));

  while(gtk_events_pending())
    gtk_main_iteration();

}

/** pops up a message dialog */
void popup(char *message)
{

  GtkWidget *dialog, *label, *okButton;
  /* Create the widgets */
  dialog = gtk_dialog_new();
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
  label = gtk_label_new(message);
  okButton = gtk_button_new_with_label("OK");

  /* Ensure that the dialog box is destroyed when the user clicks ok. */
  gtk_signal_connect_object(GTK_OBJECT(okButton), "clicked",
                            GTK_SIGNAL_FUNC(gtk_widget_destroy), GTK_OBJECT(dialog));
  gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area), okButton);

  gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox), label);

  GTK_WIDGET_SET_FLAGS(okButton, GTK_CAN_DEFAULT);
  gtk_window_set_default(GTK_WINDOW (dialog), okButton);

  gtk_widget_show_all(dialog);
}

/** pops up a message dialog asking for input */
/* TODO: cleanup */
char* popupInput(char *message, char* def)
{
  GtkWidget *dialog, *label, *input, *okButton, *cancelButton, *hbox, *vbox;
  char* rval = NULL;

  void cbOk(GtkWidget *widget, gpointer data)
  {
    int tmp;
    tmp = strlen(gtk_entry_get_text(GTK_ENTRY(input))) + 1;
    if(tmp > 1)
    {
      rval = (char*) malloc(tmp);
      memcpy(rval, gtk_entry_get_text(GTK_ENTRY(input)), tmp);
    }
    gtk_window_set_modal(GTK_WINDOW(dialog), FALSE);
    gtk_widget_destroy(GTK_WIDGET(dialog));
    gtk_main_quit();
  }

  void cbCancel(GtkWidget *widget, gpointer data)
  {
    gtk_window_set_modal(GTK_WINDOW(dialog), FALSE);
    gtk_widget_destroy(GTK_WIDGET(dialog));
    gtk_main_quit();
  }

  /* Create the widgets */
  dialog = gtk_dialog_new();
  gtk_window_set_modal(GTK_WINDOW(dialog), TRUE);
  label = gtk_label_new(message);
  input = gtk_entry_new();
  if(def)
    gtk_entry_set_text(GTK_ENTRY(input), def);

  okButton = gtk_button_new_with_label("OK");
  cancelButton = gtk_button_new_with_label("Cancel");
  hbox = gtk_hbox_new(TRUE, 0);
  vbox = gtk_vbox_new(TRUE, 0);

  gtk_box_pack_start(GTK_BOX(hbox), okButton, TRUE, TRUE, 0);
  gtk_box_pack_end(GTK_BOX(hbox), cancelButton, TRUE, TRUE, 0);

  gtk_box_pack_start(GTK_BOX(vbox), label, TRUE, TRUE, 0);
  gtk_box_pack_end(GTK_BOX(vbox), input, TRUE, TRUE, 0);

  /* Ensure that the dialog box is destroyed when the user clicks ok. */
  gtk_signal_connect(GTK_OBJECT(okButton), "clicked",
                     GTK_SIGNAL_FUNC(cbOk), NULL);
  gtk_signal_connect(GTK_OBJECT(cancelButton), "clicked",
                     GTK_SIGNAL_FUNC(cbCancel), NULL);
  gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->action_area),
                    hbox);

  gtk_container_add(GTK_CONTAINER(GTK_DIALOG(dialog)->vbox),
                    vbox);

  /*
  GTK_WIDGET_SET_FLAGS(okButton, GTK_CAN_DEFAULT);
  gtk_window_set_default(GTK_WINDOW (dialog), okButton);
  */

  gtk_widget_show_all(dialog);

  /* wait until dialog finishes*/
  gtk_main();

  return rval;
}

/** pops up a file chooser */
char* getFilename()
{
  GtkWidget *fSel;
  char* rval = NULL;

  void cbOk(GtkWidget *widget, gpointer data)
  {
    int tmp;
    tmp = strlen(gtk_file_selection_get_filename(GTK_FILE_SELECTION(fSel))) + 1;
    rval = (char*) malloc(tmp);
    memcpy(rval, gtk_file_selection_get_filename(GTK_FILE_SELECTION(fSel)), tmp);
    gtk_window_set_modal(GTK_WINDOW(fSel), FALSE);
    gtk_widget_destroy(GTK_WIDGET(fSel));
    gtk_main_quit();
  }

  void cbCancel(GtkWidget *widget, gpointer data)
  {
    gtk_window_set_modal(GTK_WINDOW(fSel), FALSE);
    gtk_widget_destroy(GTK_WIDGET(fSel));
    gtk_main_quit();
  }

  fSel = gtk_file_selection_new("Choose a file");
  gtk_window_set_modal(GTK_WINDOW(fSel), TRUE);

  gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(fSel)->ok_button),
                            "clicked",
                            GTK_SIGNAL_FUNC(cbOk),
                            (gpointer) fSel);
  gtk_signal_connect_object(GTK_OBJECT(GTK_FILE_SELECTION(fSel)->cancel_button),
                            "clicked",
                            GTK_SIGNAL_FUNC(cbCancel),
                            (gpointer) fSel);
  gtk_widget_show(GTK_WIDGET(fSel));
  gtk_main();

  return rval;
}

/*************************************************************************
Drawing stuff
*************************************************************************/

/** Redraws the current pixmap on the drawarea */
void redraw()
{
  gdk_draw_pixmap(drawArea->window,
                  drawArea->style->fg_gc[GTK_WIDGET_STATE(drawArea)],
                  pixmap,
                  0, 0,
                  0, 0,
                  drawArea->allocation.width, drawArea->allocation.height);
}

void drawMCPoly()
{
  t_polygon *poly;
  t_point tmp;
  GdkPoint *gdkPoly;
  int i, count = 0;;

  MCreset();
  while(poly = MCgetNextPolygon())
  {
    gdkPoly = (GdkPoint *)ercalloc(BPsizeOf(poly), sizeof(GdkPoint));
    for(i=0; i<BPsizeOf(poly);i++)
    {
    	tmp = PAgetPoint(pArray, BPgetPIndex(poly, i + 1));
      gdkPoly[i].x = (gint16)((ZMxCoordToZoom(tmp.x) * ((double) getDrawAreaWidth())) + 0.5);
      gdkPoly[i].y = (gint16)(((1.0 - ZMyCoordToZoom(tmp.y)) * ((double) getDrawAreaHeight())) + 0.5);
    }

    if(MFfillPoly && !(solarisToggle->active && MFxpSize > 65535))
      if(count != 0)
        gdk_draw_polygon(pixmap, gcHoles, TRUE, gdkPoly, BPsizeOf(poly));
      else if(MFfillPoly)
        gdk_draw_polygon(pixmap, gcFill, TRUE, gdkPoly, BPsizeOf(poly));

    for(i=0; i < BPsizeOf(poly) - 1;i++)
      gdk_draw_line(pixmap, gcOutline, gdkPoly[i].x, gdkPoly[i].y, gdkPoly[i+1].x, gdkPoly[i+1].y);

    gdk_draw_line(pixmap, gcOutline, gdkPoly[0].x, gdkPoly[0].y, gdkPoly[BPsizeOf(poly)-1].x, gdkPoly[BPsizeOf(poly)-1].y);

    erfree(gdkPoly);
    count++;
  }
}

/** Redraws the Points and the Polygon */
void redrawAll()
{
  gdk_draw_rectangle (pixmap,
                      drawArea->style->black_gc,
                      TRUE,
                      0, 0,
                      drawArea->allocation.width,
                      drawArea->allocation.height);
  if(!MCP)
    YOdrawPoly();
  else
    drawMCPoly();

  POdrawPoints();
  redraw();
}

int getDrawAreaWidth()
{
  return drawArea->allocation.width;
}

int getDrawAreaHeight()
{
  return drawArea->allocation.height;
}


//Mainmenu config
static GtkItemFactoryEntry menuItems[] = {
      { "/_File",                              NULL,         NULL, 0, "<Branch>" },
      { "/File/Reset Generator",               NULL,         cbFile, 1, NULL },
      { "/File/Set Seed",                      NULL,         cbFile, 2, NULL },
      { "/File/Set Delta",                     NULL,         cbFile, 3, NULL },
      { "/File/sep1",                          NULL,         cbNotImp, 0, "<Separator>" },
      { "/File/Write Ipe File",                NULL,         cbWriteFile, 1, NULL },
      { "/File/Write Voronoi File",            NULL,         cbWriteFile, 2, NULL },
      { "/File/Write Poly File",               NULL,         cbWriteFile, 3, NULL },
      { "/File/sep3",                          NULL,         cbNotImp, 0, "<Separator>" },
      { "/File/_Quit",                         "<control>Q", gtk_main_quit, 9, NULL },

      { "/_Points",                            NULL,         NULL, 0, "<Branch>" },
      { "/Points/Load Points",                 NULL,         cbLSPoint, 1, NULL },
      { "/Points/Save Points",                 NULL,         cbLSPoint, 2, NULL },
      { "/Points/sep1",                        NULL,         cbNotImp, 0, "<Separator>" },
      { "/Points/Random Points (Square)",      NULL,         cbGenPoint, 1, NULL },
      { "/Points/Random Points (Circle)",      NULL,         cbGenPoint, 2, NULL },
      { "/Points/Random Points (Clustered)",   NULL,         cbGenPoint, 3, NULL },
      { "/Points/sep2",                        NULL,         cbNotImp, 0, "<Separator>" },
      { "/Points/Add Points",                  NULL,         cbARPoints, 1, "<ToggleItem>" },
      { "/Points/Delete Points",               NULL,         cbARPoints, 2, "<ToggleItem>" },
      { "/Points/sep3",                        NULL,         cbNotImp, 0, "<Separator>" },
      { "/Points/Clear Points",                NULL,         cbClearPoints, 0, NULL },

      { "/P_olygons",                          NULL,         NULL, 0, "<Branch>" },
      { "/Polygons/Load Polygon",              NULL,         cbLSPoly, 1, NULL },
      { "/Polygons/Save Polygon",              NULL,         cbLSPoly, 2, NULL },
      { "/Polygons/sep1",                      NULL,         cbNotImp, 0, "<Separator>" },
      { "/Polygons/Smooth Polygon",            NULL,         cbCalcPoly, 1, NULL },
      { "/Polygons/Bouncing Vertices",         NULL,         cbCalcPoly, 2, NULL },
      { "/Polygons/X Monotone",                NULL,         cbCalcPoly, 3, NULL },
      { "/Polygons/Arrange Star",              NULL,         cbCalcPoly, 4, NULL },
      { "/Polygons/Star Universe",             NULL,         cbCalcPoly, 5, NULL },
      { "/Polygons/Quick Star",                NULL,         cbCalcPoly, 6, NULL },
      { "/Polygons/Steady Growth",             NULL,         cbCalcPoly, 7, NULL },
      { "/Polygons/2-Opt Moves",               NULL,         cbCalcPoly, 8, NULL },
      { "/Polygons/Space Partitioning",        NULL,         cbCalcPoly, 9, NULL },
      { "/Polygons/Permute & Reject",          NULL,         cbCalcPoly, 10, NULL },
      { "/Polygons/Incremential Construction", NULL,         cbCalcPoly, 11, NULL },
      { "/Polygons/Triangle Select",           NULL,         cbCalcPoly, 12, NULL },
      { "/Polygons/sep2",                      NULL,         cbNotImp, 0, "<Separator>" },
      { "/Polygons/Multiply Connected Polygon",NULL,         cbCalcPoly, 13, NULL },

      { "/_Analysis",                          NULL,         NULL, 0, "<Branch>" },
      { "/Analysis/Angle Distribution",        NULL,         cbAnalysis, 1, NULL },
      { "/Analysis/Slope Distribution",        NULL,         cbAnalysis, 2, NULL },
      { "/Analysis/Length Distribution",       NULL,         cbAnalysis, 3, NULL },
      { "/Analysis/Sinuositiy",                NULL,         cbASino, 0, NULL },
      { "/Analysis/sep1",                      NULL,         cbNotImp, 0, "<Separator>" },
      { "/Analysis/Write to File",             NULL,         cbAFile, 0, "<ToggleItem>" },

      { "/_View",                              NULL,         NULL, 0, "<Branch>" },
      { "/View/Original Scale",                NULL,         cbView, 1, NULL },
      { "/View/Best Fit",                      "<control>B", cbView, 2, NULL },
      { "/View/sep1",                          NULL,         cbNotImp, 0, "<Separator>" },
      { "/View/Zoom In",                       "<control>I", cbView, 3, NULL },
      { "/View/Zoom Out",                      "<control>O", cbView, 4, NULL },
      { "/View/Select Zoom Region",            NULL,         cbView, 5, NULL },
      { "/View/sep2",                          NULL,         cbNotImp, 0, "<Separator>" },
      { "/View/Polygon Fill",                  NULL,         cbView, 6, "<ToggleItem>" },
      { "/View/Point Markers",                 NULL,         cbView, 7, "<ToggleItem>" },
      { "/View/sep3",                          NULL,         cbNotImp, 0, "<Separator>" },
      { "/View/Sun X Server Workaround",   NULL,         cbView, 8, "<ToggleItem>" },

      { "/_Help",                              NULL,         NULL, 0, "<LastBranch>" },
      { "/_Help/About",                        NULL,         cbAbout, 0, NULL },
    };

/** Build the menu */
GtkWidget* createMainMenu(GtkWidget *window)
{
  GtkWidget *menuBar;
  GtkAccelGroup *accelGroup;
  gint nMenuItems = sizeof (menuItems) / sizeof (menuItems[0]);

  accelGroup = gtk_accel_group_new();

  itemFactory = gtk_item_factory_new(GTK_TYPE_MENU_BAR, "<main>", accelGroup);

  gtk_item_factory_create_items(itemFactory, nMenuItems, menuItems, NULL);

  gtk_window_add_accel_group(GTK_WINDOW (window), accelGroup);

  polyFillToggle = GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(itemFactory, "/View/Polygon Fill"));
  pointMarkersToggle= GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(itemFactory, "/View/Point Markers"));
  addPointsToggle = GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(itemFactory, "/Points/Add Points"));
  delPointsToggle = GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(itemFactory, "/Points/Delete Points"));
  writeFileToggle = GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(itemFactory, "/Analysis/Write to File"));
  solarisToggle = GTK_CHECK_MENU_ITEM(gtk_item_factory_get_widget(itemFactory, "/View/Sun X Server Workaround"));

  polyFillToggle->active = MFfillPoly;
  pointMarkersToggle->active = MFmarkPoints;
  writeFileToggle->active = aGetFile();

  return gtk_item_factory_get_widget(itemFactory, "<main>");
}

/** Builds the main GUI */
void createGUI(void)
{
  GtkWidget *mainBox, *menubar, *pane, *scrollbox, *vscrollbar, *commandInput, *aspectFrame;

  //setup main window
  mainWnd = gtk_window_new(GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title(GTK_WINDOW(mainWnd), "RPG");
  gtk_widget_set_usize(GTK_WIDGET(mainWnd), 800, 900);

  gtk_signal_connect(GTK_OBJECT(mainWnd), "delete_event",
                     GTK_SIGNAL_FUNC(cbDeleteEvent), NULL);
  gtk_signal_connect(GTK_OBJECT (mainWnd), "destroy",
                     GTK_SIGNAL_FUNC(cbDestroy), NULL);

  //create layoutbox
  mainBox = gtk_vbox_new(FALSE, 0);
  gtk_widget_show(mainBox);
  gtk_container_add(GTK_CONTAINER(mainWnd), mainBox);

  //setup menu
  menubar = createMainMenu(GTK_WIDGET(mainWnd));
  gtk_box_pack_start(GTK_BOX(mainBox), menubar, FALSE, TRUE, 0);
  gtk_widget_show(menubar);

  //setup pane window for draw and text area
  pane = gtk_vpaned_new();
  gtk_box_pack_start(GTK_BOX(mainBox), pane, TRUE, TRUE, 0);
  //gtk_paned_set_handle_size(GTK_PANED(pane), 0);
  gtk_widget_show(pane);

  aspectFrame = gtk_aspect_frame_new (NULL, 0.5, 0.5, 1, FALSE);

  gtk_widget_show (aspectFrame);

  //setup draw area
  drawArea = gtk_drawing_area_new();
  gtk_signal_connect(GTK_OBJECT(drawArea), "configure_event",
                     GTK_SIGNAL_FUNC(cbAreaResize), NULL);
  gtk_signal_connect(GTK_OBJECT(drawArea), "expose_event",
                     GTK_SIGNAL_FUNC(cbAreaRedraw), NULL);
  gtk_signal_connect(GTK_OBJECT(drawArea), "button_press_event",
                     GTK_SIGNAL_FUNC(cbAreaClick), NULL);
  gtk_signal_connect(GTK_OBJECT(drawArea), "button_release_event",
                     GTK_SIGNAL_FUNC(cbAreaRelease), NULL);
  gtk_signal_connect(GTK_OBJECT(drawArea), "motion_notify_event",
                     GTK_SIGNAL_FUNC(cbAreaMove), NULL);
  gtk_signal_connect(GTK_OBJECT(drawArea), "leave_notify_event",
                     GTK_SIGNAL_FUNC(cbAreaLeave), NULL);

  gtk_widget_set_events (drawArea, GDK_EXPOSURE_MASK
                         | GDK_BUTTON_PRESS_MASK
                         | GDK_BUTTON_RELEASE_MASK
                         | GDK_POINTER_MOTION_MASK
                         | GDK_POINTER_MOTION_HINT_MASK
                         | GDK_LEAVE_NOTIFY_MASK);

  gtk_widget_set_usize (drawArea, 800, 800);
  gtk_container_add (GTK_CONTAINER(aspectFrame), drawArea);
  gtk_widget_show(drawArea);
  //////
  //gtk_box_pack_start(GTK_BOX(mainBox), aspectFrame, TRUE, TRUE, 0);
  gtk_paned_pack1(GTK_PANED(pane), GTK_WIDGET(aspectFrame), TRUE, TRUE);
  /////

  //setup output window with scrollbar
  scrollbox = gtk_hbox_new(FALSE, 0);
  gtk_widget_show(scrollbox);

  textOutput = gtk_text_new (NULL, NULL);
  gtk_text_set_editable(GTK_TEXT (textOutput), FALSE);
  gtk_box_pack_start(GTK_BOX(scrollbox), textOutput, TRUE, TRUE, 0);
  gtk_widget_show(textOutput);

  vscrollbar = gtk_vscrollbar_new(GTK_TEXT(textOutput)->vadj);
  gtk_box_pack_end(GTK_BOX(scrollbox), vscrollbar, FALSE, FALSE, 0);
  gtk_widget_show (vscrollbar);

  gtk_paned_pack2(GTK_PANED(pane), GTK_WIDGET(scrollbox), FALSE, TRUE);
  gtk_paned_set_position(GTK_PANED(pane), 800);

  out("Welcome to the Random Polygon Generator v");
  out(VERSION);
  out("\n");

  gtk_widget_show(mainWnd);
}

/** Initializes the Graphic Contexts (colors) */
void initGCs()
{
  GdkColor color;

  //Outline
  color.red = 40000;
  color.blue = 40000;
  color.green = 40000;

  gdk_colormap_alloc_color(gtk_widget_get_colormap(GTK_WIDGET(drawArea)),
                           &color,
                           FALSE, TRUE);
  gcOutline = gdk_gc_new(GTK_WIDGET(drawArea)->window);
  gdk_gc_set_foreground(gcOutline, &color);

  //Fill
  color.red = 30000;
  color.blue = 0;
  color.green = 0;

  gdk_colormap_alloc_color(gtk_widget_get_colormap(GTK_WIDGET(drawArea)),
                           &color,
                           FALSE, TRUE);
  gcFill = gdk_gc_new(GTK_WIDGET(drawArea)->window);
  gdk_gc_set_foreground(gcFill, &color);

  //Points
  color.red = 65535;
  color.blue = 65535;
  color.green = 65535;

  gdk_colormap_alloc_color(gtk_widget_get_colormap(GTK_WIDGET(drawArea)),
                           &color,
                           FALSE, TRUE);
  gcPoint = gdk_gc_new(GTK_WIDGET(drawArea)->window);
  gdk_gc_set_foreground(gcPoint, &color);

  //Black background
  color.red = 30000;
  color.blue = 0;
  color.green = 30000;

  gdk_colormap_alloc_color(gtk_widget_get_colormap(GTK_WIDGET(drawArea)),
                           &color,
                           FALSE, TRUE);
  gcHoles = gdk_gc_new(GTK_WIDGET(drawArea)->window);
  gdk_gc_set_foreground(gcHoles, &color);
}

/** Initializes GTK and launches the gui */
void launchGUI(int argc, char *argv[])
{
  printf("Starting GUI\n");

	gtk_init(&argc, &argv);

  MFfillPoly = TRUE;
  /* mark the points by default */
  MFmarkPoints = TRUE;
  /* init the number of points for the filled polygon */
  MFxpSize = 0;
  createGUI();
  initGCs();

  gtk_main();
}
