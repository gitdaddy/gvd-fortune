#include "zoom.h"
//#include "formOps.h"
#include "stateLine.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/

static t_point ZMminPoint,ZMmaxPoint,ZMfirstPoint;
static enum t_ZMactionState ZMactionState = ZM_NONE;

/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
double ZMxZoomToCoord(double x)
{
  double xcord;

  xcord = X_MIN+((x*(ZMmaxPoint.x-ZMminPoint.x)+ZMminPoint.x)*(X_MAX-X_MIN));
  return(xcord);
};

double ZMyZoomToCoord(double y)
{
  double ycord;

  ycord = Y_MIN+((y*(ZMmaxPoint.y-ZMminPoint.y)+ZMminPoint.y)*(Y_MAX-Y_MIN));
  return(ycord);
};

double ZMxCoordToZoom(double x)
{
  double xnorm;

  xnorm =(((x-X_MIN)/(X_MAX-X_MIN))-ZMminPoint.x)/(ZMmaxPoint.x-ZMminPoint.x);
  return(xnorm);
};

double ZMyCoordToZoom(double y)
{
  double ynorm;

  ynorm =(((y-Y_MIN)/(Y_MAX-Y_MIN))-ZMminPoint.y)/(ZMmaxPoint.y-ZMminPoint.y);
  return(ynorm);
};

int ZMclipPoint(t_point aPoint)
{
  double x,y;
  
  x = (aPoint.x - X_MIN) / (X_MAX-X_MIN);
  y = (aPoint.y - Y_MIN) / (Y_MAX-Y_MIN);

  return((x >= ZMminPoint.x) &&
	 (y >= ZMminPoint.y) &&
	 (x <= ZMmaxPoint.x) &&
	 (y <= ZMmaxPoint.y));
};

int ZMclipLine(t_point *point1,t_point *point2)
{
  double x1,y1,x2,y2;

  x1 = (point1->x - X_MIN) / (X_MAX-X_MIN);
  y1 = (point1->y - Y_MIN) / (Y_MAX-Y_MIN);
  x2 = (point2->x - X_MIN) / (X_MAX-X_MIN);
  y2 = (point2->y - Y_MIN) / (Y_MAX-Y_MIN);

  return(!((MAX(x1,x2) < ZMminPoint.x) &&
	   (MAX(y1,y2) < ZMminPoint.y) &&
	   (MIN(x1,x2) > ZMmaxPoint.x) &&
	   (MIN(y1,y2) > ZMmaxPoint.y)));
};

void ZMoriginalScale()
{
  t_point minPoint,maxPoint;

  minPoint.x = X_MIN;
  minPoint.y = Y_MIN;
  maxPoint.x = X_MAX;
  maxPoint.y = Y_MAX;

  ZMsetZoom(minPoint,maxPoint);
};

void ZMzoomIn()
{
  t_point newMin,newMax;

  newMin.x = ZMminPoint.x + 0.05 * (ZMmaxPoint.x-ZMminPoint.x);
  newMin.y = ZMminPoint.y + 0.05 * (ZMmaxPoint.y-ZMminPoint.y);
  newMax.x = ZMmaxPoint.x - 0.05 * (ZMmaxPoint.x-ZMminPoint.x);
  newMax.y = ZMmaxPoint.y - 0.05 * (ZMmaxPoint.y-ZMminPoint.y);

  ZMsetZoom(newMin,newMax);
};

void ZMzoomOut()
{
  t_point newMin,newMax;

  newMin.x = ZMminPoint.x - 0.05 * (ZMmaxPoint.x-ZMminPoint.x);
  newMin.y = ZMminPoint.y - 0.05 * (ZMmaxPoint.y-ZMminPoint.y);
  newMax.x = ZMmaxPoint.x + 0.05 * (ZMmaxPoint.x-ZMminPoint.x);
  newMax.y = ZMmaxPoint.y + 0.05 * (ZMmaxPoint.y-ZMminPoint.y);

  ZMsetZoom(newMin,newMax);
};

void ZMbestFit(t_pointList *pList)
{
  t_point minPoint,maxPoint;
  double xdist,ydist;
  
  PLgetMinMax(pList,&minPoint,&maxPoint);
  
  xdist = maxPoint.x - minPoint.x;
  ydist = maxPoint.y - minPoint.y;

  minPoint.x -= 0.05 * xdist;
  minPoint.y -= 0.05 * ydist;
  maxPoint.x += 0.05 * xdist;
  maxPoint.y += 0.05 * ydist;

  ZMsetZoom(minPoint,maxPoint);
};

void ZMsetZoom(t_point minPoint,t_point maxPoint)
{
  /* the aspect ratio of the zooming area must be the same 
     as for the coordinates! */
  double xdist,ydist,xsplit,ysplit;

  if (!equalPoints(minPoint,maxPoint))
    {
      ZMminPoint.x = MIN(minPoint.x,maxPoint.x);
      ZMminPoint.y = MIN(minPoint.y,maxPoint.y);
      ZMmaxPoint.x = MAX(minPoint.x,maxPoint.x);
      ZMmaxPoint.y = MAX(minPoint.y,maxPoint.y);
      
      xdist = (ZMmaxPoint.x-ZMminPoint.x)/(X_MAX-X_MIN);
      ydist = (ZMmaxPoint.y-ZMminPoint.y)/(Y_MAX-Y_MIN);
      
      xdist = MAX(xdist,ydist);
      ydist = xdist * (Y_MAX-Y_MIN);
      xdist = xdist * (X_MAX-X_MIN);
      
      xsplit = (xdist + ZMminPoint.x - ZMmaxPoint.x)/2.0;
      ysplit = (ydist + ZMminPoint.y - ZMmaxPoint.y)/2.0;
      
      if (!deltaAbs(xsplit))
	{
	  ZMminPoint.x -= xsplit;
	  ZMmaxPoint.x += xsplit;
	};
	
	if (!deltaAbs(ysplit))
	  {
	    ZMminPoint.y -= ysplit;
	    ZMmaxPoint.y += ysplit;
	  };  
    };
};

void ZMsetAction()
{
  ZMactionState = ZM_FIRST;
  SLsetState(ST_ZOOM1);
};

void ZMclearAction()
{
  ZMactionState = ZM_NONE;
  SLsetState(ST_OK);
};

void ZMdoAction(double x,double y)
{
  t_point minPoint,maxPoint;

  switch(ZMactionState)
    {
    case ZM_FIRST:
      ZMfirstPoint.x = ZMxZoomToCoord(x);
      ZMfirstPoint.y = ZMyZoomToCoord(y);
      ZMactionState = ZM_SECOND;
      SLsetState(ST_ZOOM2);
      break;

    case ZM_SECOND:
      minPoint.x = MIN(ZMfirstPoint.x,ZMxZoomToCoord(x));
      minPoint.y = MIN(ZMfirstPoint.y,ZMyZoomToCoord(y));
      maxPoint.x = MAX(ZMfirstPoint.x,ZMxZoomToCoord(x));
      maxPoint.y = MAX(ZMfirstPoint.y,ZMyZoomToCoord(y));
      if (!equalPoints(minPoint,maxPoint))
	ZMsetZoom(minPoint,maxPoint);

      ZMclearAction();
 
      MFredrawFree();
      break;

    default:
      break;
    };
};



