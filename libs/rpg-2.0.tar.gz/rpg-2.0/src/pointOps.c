/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#include "pointOps.h"	
#include "polyOps.h"	
#include "pointList.h"	
#include "pointArray.h"	
//#include "formOps.h"
#include "basicDefs.h"	
#include "stateLine.h"	
#include "ipeWrite.h"
#include "zoom.h"

#include "gtkgui.h"
#include <stdio.h>

/********************************************************************/
/*                                                                  */
/* Constants and global variables                                   */
/*                                                                  */
/********************************************************************/

static t_pointList aList;

static enum t_POactionState POactionState = NONE; 


/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/

void POinit()
{
  POactionState = NONE;
  PLinitList(&aList);
};

void POfree()
{
  PLfreeList(&aList);
};

t_pointList* POgetPointList()
{
 return(&aList);
};

void POloadPoints(char *fileName)
{
  t_pointArray auxArray;

  if (fileName != NULL)
  {
    POclearPoints();

    PAinitArray(&auxArray,0);

    if (!PAreadFile(&auxArray,fileName))
    {
      SLsetState(ST_FLE_N_FND);
    }
    else
    {
      PAsortArray(&auxArray);
      PAcreateList(&auxArray,&aList);
    };

    PAfreeArray(&auxArray);

    MFredrawFree();
  };
};

void POwritePoints(char *fileName)
{
  if (fileName != NULL)
  {
    if (!PLwriteFile(&aList,fileName))
      SLsetState(ST_FLE_N_FND);

    MFredrawFree();
  };
};

void POdelPoint(double x,double y,double epsilon)
{
  t_point aPoint;

  YOclearPoly();
  aPoint.x = ZMxZoomToCoord(x);
  aPoint.y = ZMyZoomToCoord(y);
  PLdelEpsilonPoints(&aList,aPoint,epsilon);
  MFredrawFree();
};

void POaddPoint(double x,double y)
{
  t_point aPoint;

  YOclearPoly();
  aPoint.x = ZMxZoomToCoord(x);
  aPoint.y = ZMyZoomToCoord(y);
  PLaddPoint(&aList,aPoint);
  MFredrawFree();
};

void POclearPoints()
{
  YOclearPoly();
  PLfreeList(&aList);
  PLinitList(&aList);
  MFredrawFree();
};

void POdoAction(double x,double y,double epsilon)
{
  switch(POactionState)
  {
  case ADD: 
    POaddPoint(x,y);
    break;    
  
  case DELETE:
    POdelPoint(x,y,epsilon);
    break;

  default:
    break;
  };
};

void POclearAction()
{
  POactionState = NONE;
  SLsetState(ST_OK);
};

void POsetActionAdd()
{
  POactionState = ADD;
  SLsetState(ST_ADD_P);
};

void POsetActionDelete()
{
  POactionState = DELETE;
  SLsetState(ST_DEL_P);
};

void POipeWrite(FILE *ipeFile)
{
  t_pointArray pArray;

  PAlistInitArray(&pArray,&aList);
  IWwritePoints(ipeFile,&pArray);

  PAfreeArray(&pArray);
};

void POdrawPoints()
{
  t_point aPoint;
	PLresetList(&aList);

  while (PLgetCurrentPoint(&aList,&aPoint))
  {
    if (ZMclipPoint(aPoint))
    	MFdrawPoint(ZMxCoordToZoom(aPoint.x),ZMyCoordToZoom(aPoint.y));
  };
};

void POgenerateRandomPoints(int nrOfPoints)
{
  YOclearPoly();
  PLaddRandomPoints(&aList,nrOfPoints);
  MFredrawFree();
};

void POgenerateRandomCirclePoints(int nrOfPoints)
{
  YOclearPoly();
  PLaddRandomCirclePoints(&aList,nrOfPoints);
  MFredrawFree();
};


void POgenerateClusterPoints(int nrOfPoints)
{
  YOclearPoly();
  PLaddClusterPoints(&aList,nrOfPoints);
  MFredrawFree();
};









