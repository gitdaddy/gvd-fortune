#include <stdio.h>
#include "pointArray.h"
#include "basicPoly.h"
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/
#ifndef __IPEWRITE_H_
#define __IPEWRITE_H_

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/

#define IPE_MIN         (-150.0)
#define IPE_MAX          150.0

/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/
FILE *IWopenFile(char *fileName);

void IWwriteFrame(FILE *ipeFile);

void IWwritePoints(FILE *ipeFile,t_pointArray *pArray);

void IWwritePoly(FILE *ipeFile,t_polygon *aPoly,t_pointArray *pArray);

void IWcloseFile(FILE *ipeFile);

#endif
