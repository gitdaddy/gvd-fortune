#include "outWrite.h"
#include "argEval.h"
#include "ipeWrite.h"
#include "withX.h"
#include "polyOps.h"
#include "pointOps.h"
#include <stdio.h>
#include <string.h>
/********************************************************************/
/*                                                                  */
/* tom 20/11/95                                                     */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/


void OWipe(char *outFile)
{
  FILE *ipeFile;
  
  ipeFile = IWopenFile(outFile);
  
  IWwriteFrame(ipeFile);
  POipeWrite(ipeFile);
  YOipeWrite(ipeFile);
  
  IWcloseFile(ipeFile);
};

void OWwrite(char *outFile,int format)
{
  if (((strlen(outFile) > 0) || (!isWithX()))
      && (strcasecmp(outFile,"none") != 0))
    {
      if (format == STANDARD)
	YOwritePoly(outFile);
      else if (format == IPE)
	OWipe(outFile);
      else if (format == VORONOI)
	YOwriteVoronoi(outFile);
      else if (format == POLY)
	YOwriteMartin(outFile);
    }
};






