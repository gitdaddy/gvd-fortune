#include<stdio.h>

#ifndef __BASICIO_H_
#define __BASICIO_H_


/********************************************************************/
/*                                                                  */
/* Constants and the like                                           */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Data Types                                                       */
/*                                                                  */
/********************************************************************/



/********************************************************************/
/*                                                                  */
/* Procedures and functions                                         */
/*                                                                  */
/********************************************************************/


FILE *FopenRead(char *fileName);

FILE *FopenWrite(char *fileName);

void Fheader(FILE *aFile);

void FreadLine(FILE *aFile,char *aLine,int lineSize);

int Fclose(FILE *aFile);

#endif
