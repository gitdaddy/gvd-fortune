/***************************************************************************
 *   Copyright (C) 2003 by Martin Heimlich                                 *
 *   mheimlich@cosy.sbg.ac.at                                              *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#ifndef __GTKGUI_H_
#define __GTKGUI_H_

/* radius for drawing the points */
#define RADIUS 3 /* Pixel */
/* epsilon environment for deleting points */
#define EPSILON 3 /* Pixel */

#include <gtk/gtk.h>

/* formOps wrapper functions */
void MFredrawFree();
void MFinitFPoly(int size);
void MFaddToFPoly(double x,double y,int index);
void MFdrawPoint(double x,double y);
void MFdrawFPoly();

/* the new gui */
void launchGUI(int argc, char *argv[]);

/* Service functions */
void guip(char *msg);
void out(char *msg);
void popup(char *message);
char* popupInput(char *message, char* def);
char* getFilename();

/* drawing stuff */
void redraw(void);
void redrawAll(void);
int getDrawAreaWidth();
int getDrawAreaHeight();

#endif
